/*
 * reserved comment block
 * DO NOT REMOVE OR ALTER!
 */
/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package com.sun.org.apache.xml.internal.security.utils;

public final class EncryptionConstants {

    /** The namespace of the
     * <A HREF="http://www.w3.org/TR/2001/WD-xmlenc-core-20010626/">
     * XML Encryption Syntax and Processing</A> */
    public static final String EncryptionSpecNS =
        "http://www.w3.org/2001/04/xmlenc#";

    private EncryptionConstants() {
        // we don't allow instantiation
    }

}
